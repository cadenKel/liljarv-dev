# Automation Workflow Library — Core

10 production-ready automation workflows for n8n, Make, and Zapier.

## Workflows Included
1. email-triage — Classify and route incoming emails
2. calendar-booking — Auto-accept/decline meeting requests
3. crm-update — Sync form submissions to CRM
4. invoice-processing — Extract invoice data and route for approval
5. supplier-email — Auto-generate supplier order confirmations
6. lead-qualification — Score and qualify inbound leads
7. support-ticket — Create and prioritise support tickets
8. social-post — Schedule and publish social media content
9. daily-report — Compile and send daily metrics report
10. expense-approval — Route expense claims for approval

## Usage
Import any .json file directly into n8n via Settings > Import Workflow.
Each workflow includes nodes, connections, and parameter stubs — update credentials and field mappings for your setup.

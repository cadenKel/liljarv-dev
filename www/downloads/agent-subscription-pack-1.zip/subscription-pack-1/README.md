# Monthly Agent Subscription — Pack 1
Best-of bundle: 50 system prompts + 5 workflows + 20 SMB profiles + 5 compliance chunks.

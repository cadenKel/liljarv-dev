# Conflict Resolution Tree
## Identify the conflict type
- Internal (team disagreement) → schedule facilitated discussion within 48h
- External (customer/partner) → assign senior account owner, escalate if unresolved in 5 days
- Legal (contractual dispute) → route to legal immediately

## De-escalation steps
1. Acknowledge the issue without admitting liability
2. Identify the desired outcome from each party
3. Find common ground or acceptable compromise
4. Document resolution and prevent recurrence

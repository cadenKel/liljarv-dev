# Refund Tree
Same as starter — see refund-policy.md in starter pack.
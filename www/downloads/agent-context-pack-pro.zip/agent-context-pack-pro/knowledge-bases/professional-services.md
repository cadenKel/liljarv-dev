# Professional Services Domain Knowledge Base
- Key metrics: utilisation rate, billable hours, project margin, NPS, renewal rate
- Common agent tasks: project scheduling, timesheet reminders, invoice generation, proposal drafting
- Typical pain points: scope creep, resource allocation, cash flow, client dependency

# Retail Domain Knowledge Base
- Peak trading periods: Christmas, Black Friday, Back to School
- Key metrics: conversion rate, AOV, basket abandonment, ROAS
- Common agent tasks: inventory alerts, promotional scheduling, customer service, returns processing
- Typical pain points: inventory management, seasonal staffing, margin pressure from discounting

# SaaS Domain Knowledge Base
- Key metrics: MRR, ARR, churn rate, LTV, CAC, NPS, DAU/MAU
- Common agent tasks: onboarding automation, renewal reminders, usage alerts, support triage
- Typical pain points: churn, feature adoption, pricing strategy, enterprise sales cycles

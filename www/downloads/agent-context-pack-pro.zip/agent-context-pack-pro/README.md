# Agent Context Pack — Pro

200 operator instructions across 10 domains, plus conflict resolution trees and domain knowledge bases.

## Contents
- system-prompts/prompts.jsonl — 200 operator instructions
- decision-trees/ — escalation, refund, conflict resolution trees
- knowledge-bases/ — retail, saas, professional services domain guides

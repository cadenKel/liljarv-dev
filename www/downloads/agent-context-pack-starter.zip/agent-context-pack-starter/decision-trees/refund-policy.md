# Refund Policy Decision Tree

## Eligibility Check
```
Was the purchase made within the last 30 days?
├── NO  → Refund not eligible (direct to goodwill credit discussion)
└── YES → Continue

Has the product been downloaded or accessed?
├── NO  → Full refund approved automatically
└── YES → Continue

Is there a documented defect or mis-described product?
├── YES → Full refund approved, flag product for review
└── NO  → Continue

Has the customer previously received a refund in the last 12 months?
├── YES → Partial refund (50%) maximum, escalate to manager
└── NO  → Full refund approved
```

## Processing
- Refunds return to original payment method within 5-10 business days
- Log all refunds with reason code in CRM
- Refunds over $500 require manager approval

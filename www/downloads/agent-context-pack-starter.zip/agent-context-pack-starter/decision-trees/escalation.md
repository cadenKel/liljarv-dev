# Escalation Decision Tree

## Step 1: Assess Severity
- **P1 (Critical):** Service down, data breach, safety risk → escalate immediately to supervisor
- **P2 (High):** Major feature broken, customer threatening churn → escalate within 1 hour
- **P3 (Medium):** Workaround available → resolve within 8 business hours
- **P4 (Low):** Cosmetic issue, general query → resolve within 2 business days

## Step 2: Route
```
Is the customer VIP or enterprise?
├── YES → Assign to senior rep, notify account manager
└── NO  → Standard queue

Is the issue a billing dispute?
├── YES → Route to billing team + log in disputes tracker
└── NO  → Continue standard support flow

Has the customer contacted us 3+ times for the same issue?
├── YES → Flag as recurring issue, escalate to product team
└── NO  → Resolve and close
```

## Step 3: Escalation Contacts
| Severity | First Contact | If Unavailable |
|----------|--------------|----------------|
| P1 | On-call engineer | VP Engineering |
| P2 | Team lead | Department head |
| P3 | Senior rep | Team lead |
| P4 | Any rep | N/A |

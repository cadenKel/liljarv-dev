# Agent Context Pack — Business Starter

500 operator instructions across 10 business domains, ready to inject directly into AI agent system prompts.

## Contents
- `system-prompts/prompts.jsonl` — 500 operator instructions (JSONL, one per line)
- `decision-trees/escalation.md` — Customer escalation decision tree
- `decision-trees/refund-policy.md` — Refund handling decision tree
- `policies/standard-terms.md` — Standard business policy template

## Usage
Load prompts.jsonl and filter by `domain` to find relevant instructions for your agent's context window. Each entry is a self-contained instruction suitable for a system prompt or operator policy.

## Domains Covered
customer_service, sales, hr, finance, legal, marketing, operations, it_support, logistics, procurement

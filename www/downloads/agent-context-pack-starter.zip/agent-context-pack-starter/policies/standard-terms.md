# Standard Business Policy Template

## 1. Service Delivery
All services will be delivered within the timeframes agreed in the purchase confirmation. Delays beyond 5 business days will be communicated proactively with a revised timeline.

## 2. Payment Terms
Payment is due upon purchase unless a Net 30 agreement is in place. Late payments incur a 1.5% monthly fee after a 10-day grace period.

## 3. Confidentiality
All business information shared between parties is considered confidential and may not be disclosed to third parties without written consent.

## 4. Intellectual Property
All deliverables created under this agreement remain the property of the purchaser upon full payment. Seller retains the right to display the work in their portfolio unless otherwise agreed.

## 5. Limitation of Liability
Liability is limited to the amount paid for the specific product or service in dispute. Neither party is liable for indirect or consequential damages.

## 6. Dispute Resolution
Disputes will first be addressed through good-faith negotiation. If unresolved within 30 days, disputes will proceed to binding arbitration in the applicable jurisdiction.

## 7. Governing Law
This agreement is governed by the laws of the jurisdiction in which the seller is registered.

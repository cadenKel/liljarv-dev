# Regulatory Compliance Knowledge Base

Structured knowledge base covering GDPR, CCPA, and SOC2 formatted as retrievable chunks for RAG pipelines.

## Contents
- `chunks/gdpr.jsonl` — 20 GDPR knowledge chunks
- `chunks/ccpa.jsonl` — 20 CCPA knowledge chunks
- `chunks/soc2.jsonl` — 20 SOC2 knowledge chunks

## Format
Each line is a JSON object: {id, topic, regulation, chunk (2-3 sentence explanation), source}

## Usage
Index with your preferred vector store (Pinecone, Weaviate, ChromaDB). Use the `regulation` field to filter by framework, `topic` for keyword filtering, and `chunk` as the embedding text.

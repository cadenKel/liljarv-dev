# Business Intelligence Snapshot — SMB

100 structured SMB business profiles for market research, outreach, and targeting.

## Contents
- `data/businesses.json` — 100 SMB profiles

## Fields Per Profile
- id, company_name, industry, size (employees), city, state
- decision_maker_role, decision_maker_name
- pain_points (array of 3), budget_range, contact_email

## Usage
Filter by industry or pain_point to identify prospects. Feed directly into outreach automation or CRM enrichment workflows.

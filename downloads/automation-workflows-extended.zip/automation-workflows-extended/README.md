# Automation Workflow Library — Extended

20 production-ready automation workflows including advanced finance, legal, HR, and multi-agent patterns.

## Workflows Included
Core (10): email-triage, calendar-booking, crm-update, invoice-processing, supplier-email,
           lead-qualification, support-ticket, social-post, daily-report, expense-approval

Extended (10): finance-reconciliation, legal-routing, hr-onboarding, multi-agent-handoff,
               customer-journey, contract-review, vendor-payment, compliance-check,
               data-backup, performance-report

## Usage
Import any .json file directly into n8n via Settings > Import Workflow.
